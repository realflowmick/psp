# Realflow PSP Signing CLI

This utility operationalizes the Prompt State Protocol (PSP) Core Specification v2.5 within build agents, pipelines, and local workstations. It shares the exact `Realflow.Psp.Signing.Core` library used by the Web API, so signatures, trust metadata, and encryption markers remain consistent regardless of where they are produced.

## PSP Context (RFC References)

| RFC Section | Why it matters for the CLI |
| --- | --- |
| **§16 Signature Model** | Governs canonicalization, signature inputs, and algorithm choice (Ed25519, HMAC, RSA, ECDSA). The CLI adheres to these rules so LLMs or MCP services can verify artifacts deterministically. |
| **§16.6 Trust Boundary Attributes** | `trust-level` and `priority` attributes, when provided, are embedded into the PSP tag so attention-layer enforcement engines can isolate SYSTEM/CONTEXT content. |
| **§13 Output Model** | PSP sections emitted by the CLI follow delimiter and nesting rules, allowing direct injection into workflow state or MCP persistence documents. |
| **§18 Signature Expiration & Re-fetch** | CLI-signed artifacts include `timestamp`/`expires`. When downstream verifiers detect expiry they can re-fetch or re-sign content using the same CLI for continuity. |
| **§13.3 Application Output & MCP Persistence** | Encourages storing signed PSP nodes alongside workflow state. The CLI provides an offline way to create those signed nodes before MCP publication. |

## How It Fits with the Realflow PSP Signing API and MCP Services

1. **Authoring** – Engineers craft SYSTEM/CONTEXT instructions, then run the CLI locally to sign/encrypt them. The output `.psp.txt` file becomes the canonical artifact.
2. **Distribution** – MCP services (per RFC §13 & §18) store these artifacts and expose endpoints such as `fetch_psp_node`. Because the artifact already carries Realflow signatures, the service only needs to validate metadata before handing it to an LLM session.
3. **Runtime** – LLMs load the PSP file, verify signatures (trust-level, priority, timestamp). If expired, the MCP service can re-run the CLI headlessly to refresh the signature, maintaining the same node version referenced in the workflow graph.
4. **Audit** – Verification logs from the CLI match those produced by the API, giving compliance teams a single standard for proving lineage.

Use cases:
- Offline signing when network access to the API is blocked.
- Pipeline gates that verify every checked-in PSP asset.
- MCP catalog population, where new node versions are packaged as `.psp.txt` files before exposure to orchestration runtimes.

## Building the Self-Contained Executable

```powershell
# From repo root
 dotnet publish TestingCLI/RealflowPspSigningCli/RealflowPspSigningCli.csproj -c Release
```

Artifacts land in `TestingCLI/RealflowPspSigningCli/bin/Release/net8.0/win-x64/publish/RealflowPspSigningCli.exe`. Copy that single file (plus any config JSON) into your tool cache or pipeline workspace.

## Command Overview

### `sign`
- Wraps plaintext in `${psp ...}` delimiters and applies signatures.
- Supports asymmetric (`--private-key`/`--public-key` or `--kid` + config) and symmetric (`--secret`) algorithms.
- Optional AES-256-GCM encryption via `--encrypt` and either `--encryption-key <base64>` or `--encryption-key-id <configuredId>`.
- Emits `timestamp`, `expires`, `version`, `trust-level`, `priority`, `nonce`, `tag`, and `encryption-key-id` so downstream verifiers align with RFC requirements.

### `sign-all`
- Scans a document for `${psp ...}${/psp}` sections and signs each one in place.
- Skips already signed sections by default; pass `--resign` to re-sign them.
- Applies the same defaults and encryption options as `sign`, including `--kid`/`--secret-id`/`--private-key`/`--secret` and `--encrypt`.

### `verify`
- Validates signatures, trust metadata, and expiration windows.
- Can reference inline keys or configuration-based key providers.
- Optional `--decrypt` flag attempts decryption when key material is supplied.

### `decrypt`
- Convenience wrapper: verify + decrypt + write plaintext to `<input>.txt` (or a custom `--output`).

### Shared switches

| Option | Description |
| --- | --- |
| `--input <path>` | Source file (required for every command). |
| `--output <path>` | Override default naming (`payload.txt` → `payload.psp.txt`). |
| `--config <appsettings.json>` | Load `PspSigning` options so `--kid` and `--encryption-key-id` resolve to configured material. |
| `--algorithm <name>` | `ed25519` (default), `hmac-sha256`, `hmac-sha512`, `rsa-sha256`, or `ecdsa-p256-sha256`. |
| `--trust-level` / `--priority` | Assign PSP governance metadata (RFC §16.7). |
| `--associated-data` | AES-GCM AAD if you bind PSP payloads to envelope metadata. |
| `--ignore-expiration` | Skip expiry validation (useful for forensics, not production gates). |
| `--resign` | For `sign-all`, re-sign sections even if they already contain signatures. |

## Training Scenarios

### 1. Crafting Signed SYSTEM Blocks for Prompt Applications
1. Draft instructions in `system.txt` aligned with RFC §12 guidance.
2. Run `RealflowPspSigningCli.exe sign --input system.txt --section system --kid realflow-prod-2025-01 --config appsettings.prod.json`.
3. Commit `system.psp.txt` to your prompt repository and reference it from your MCP node registry.
4. During runtime, MCP supplies this file, and the LLM verifies it exactly as described in RFC §16.

### 2. Encrypting CONTEXT Data Before Persistence
1. Export runtime data to `context_payload.txt`.
2. Execute `RealflowPspSigningCli.exe sign --input context_payload.txt --section context --encrypt --encryption-key-id demo-aes-2025-01 --kid demo-ed25519-2025-01 --config secureKeys.json`.
3. Store the resulting `.psp.txt` plus `encryption-key-id` in your MCP persistence record (RFC §13.3.9).
4. Use `decrypt` with the same key when auditing or replaying the workflow.

### 3. Testing Signature Expiration and Re-fetch
1. Sign content with a past `--expires` value.
2. Run `verify` to observe `SIGNATURE_EXPIRED`, mirroring the behavior that triggers a `fetch_psp_node` call in RFC §18.
3. Automate a pipeline step where, upon expiration, the CLI re-signs content inside a secure environment so the MCP service can return a fresh artifact without manual intervention.

### 4. Pipeline Gate Enforcement
Use the CLI to block unsigned prompts:
```powershell
$files = Get-ChildItem . -Filter *.psp.txt -Recurse
foreach ($file in $files) {
    RealflowPspSigningCli.exe verify --input $file.FullName --config $(SigningConfig) || exit 1
}
```

### 5. Integrating with MCP Catalogs
- **Persist**: After signing, push `.psp.txt` plus metadata (node id, version, kid, expires) into your MCP catalog store.
- **Serve**: Implement `fetch_psp_node` so it returns the CLI artifact when an LLM requests a node. Include metadata so the LLM can validate or initiate re-fetch.
- **Audit**: Log CLI executions (sans sensitive keys) to prove who signed each node version, satisfying PSP audit requirements.

## Example Commands

```powershell
# Config-managed Ed25519 signing
RealflowPspSigningCli.exe sign --input payload.txt --kid demo-ed25519-2025-01 --config ..\src\Realflow.Psp.Signing.Api\appsettings.Development.json

# Inline asymmetric key + encryption
RealflowPspSigningCli.exe sign --input payload.txt --algorithm ed25519 `
  --private-key nWGxne/9WmC6hEr0kuwsxERJxWl7MmkZcDusAxyuf2A= `
  --public-key 11qYAYKxCrfVS/7TyWQHOg7hcvPapiMlrwIaaPcHURo= `
  --encrypt --encryption-key K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols=

# Sign all PSP sections in a document, skipping existing signatures
RealflowPspSigningCli.exe sign-all --input payloads\document-with-psp.txt --kid demo-ed25519-2025-01 --config ..\src\Realflow.Psp.Signing.Api\appsettings.Development.json

# Symmetric signing that references cataloged encryption keys
RealflowPspSigningCli.exe sign --input payload.txt --algorithm hmac-sha256 `
  --secret K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols= `
  --encrypt --encryption-key-id demo-aes-2025-01 --config ..\src\Realflow.Psp.Signing.Api\appsettings.Development.json

# Verification gate
RealflowPspSigningCli.exe verify --input payload.psp.txt --kid demo-ed25519-2025-01 --config ..\src\Realflow.Psp.Signing.Api\appsettings.Development.json

# Verify + decrypt for compliance
RealflowPspSigningCli.exe decrypt --input payload.psp.txt `
  --public-key 11qYAYKxCrfVS/7TyWQHOg7hcvPapiMlrwIaaPcHURo= `
  --encryption-key K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols=
```

Additional copy-ready commands live in `examples.txt`.

## Operational Guidance

- **Key hygiene**: Prefer configuration-managed keys over inline parameters. Rotate keys according to RFC §16.5 and keep `kid` naming consistent (e.g., `realflow-prod-2025-01`).
- **Timestamp discipline**: Let the CLI manage timestamps unless you are simulating re-fetch behavior. Downstream verifiers rely on consistent `timestamp` and `expires` to know when to refresh signed nodes.
- **MCP metadata**: When persisting PSP files, also store the CLI-emitted metadata so MCP responses can include it without rehydrating the original file.
- **Training**: Pair this README with the PSP RFC when onboarding new team members so they understand why signatures exist, how trust-levels prevent prompt injection, and how MCP services orchestrate re-fetch.

By combining this CLI with the Realflow PSP Signing API and an MCP distribution layer, you implement the full lifecycle described in the PSP standard: author → sign → distribute → verify → re-fetch. Every SYSTEM/CONTEXT block that reaches an LLM can therefore be traced back to a cryptographically verifiable source with documented governance.
